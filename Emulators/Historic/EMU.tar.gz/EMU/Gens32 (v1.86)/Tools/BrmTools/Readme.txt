Brm Convertor v1.00 bate
==================================
Info:
Since Snake insist on make brm no compatible with gens 2.11.I build this tool for the user  who want to convert from Gens v2.11's BRM file into Fusion's crm file.

Command:

gtf:     Convert the brm of gens to fusion's.The brm file will be separate in 2 then.

ftg:     Not supported yet.

help:    Get help;

Quit:    Quit the programme.



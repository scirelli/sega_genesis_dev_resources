/***************************************************************************

    version.c

    Version string source file for MAME.

    Copyright (c) 1996-2006, Nicola Salmoria and the MAME Team.
    Visit http://mamedev.org for licensing and usage restrictions.

***************************************************************************/

char build_version[] = "HazeMD 0.12a (from MAME 0.108u5) ("__DATE__")";

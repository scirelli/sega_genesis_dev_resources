#ifndef _CDDA_H_
#define _CDDA_H_

void CDDA_set_cdrom(int num, void *file);

#endif


Motorcycle Virtual Sapce Controller v1.00
===============================================

Note:
2006 Linghui Kong,all rights reserved.You must have a license to use this software with your projects.For more information,post a email to Dark__Dancer@163.com or ACOMPAL@hotmail.com

For Gens32 Surreal's user,you can use this software freely,but you have no 
rights to distribute or sell it.



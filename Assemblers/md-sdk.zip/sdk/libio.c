/*
 * libio - standard I/O library stubs for embedded code
 */

#include <sys/stat.h>
#include <errno.h>
#include <stdio.h>

int close(int fd)
{
    return 0;
}


int fstat(int fd, struct stat *buf)
{
    buf->st_mode    = S_IFCHR;
    buf->st_blksize = 0;

    return 0;
}


int getpid(void)
{
    return 1;
}


int isatty(int fd)
{
    return 1;
}


int kill(int pid, int sig)
{
    if (pid == 1)
    {
//        _exit(sig);
    }
    return 0;
}


off_t lseek(int fd, off_t offset, int whence)
{
    errno = ESPIPE;
    return ((off_t) -1);
}


int open(const char *buf, int flags, int mode)
{
    errno = EIO;
    return -1;
}


/* print.c */


#if 0
#define outbyte(x)
#else
#include "sega.h"
  static unsigned int outbyte_col = 0;
  static unsigned int outbyte_row = 0;
  static unsigned int text_attr   = 0; // (1 << 13)

void goto_xy(int x, int y)
{
  if (x >= 0 && x < 40 && y >= 0 && y < 28)
  {
    fflush(stdout); // in case setvbuf wasn't used to turn off buffering
    outbyte_col = x;
    outbyte_row = y;
  }
}

void clear_eol(void)
{
  int col;

  *VDP_CTRL_L = NAMEA_W + (128 * outbyte_row << 16) + (outbyte_col*2 << 16);
  for (col = outbyte_col; col < 40; col++)
  {
    *VDP_DATA = 0;
  }
}

void clear_eos(void)
{
  int row,col;

  clear_eol();
  for (row = outbyte_row + 1; row < 28; row++);
  {
    *VDP_CTRL_L = NAMEA_W + (128 * row << 16);
    for (col = 0; col < 40; col++)
    {
      *VDP_DATA = 0;
    }
  }
}

void clear_screen(void)
{
#if 0
  int row,col;

  for (row = 0; row < 28; row++)
  {
    *VDP_CTRL_L = NAMEA_W + (128 * row << 16);
    for (col = 0; col < 40; col++)
    {
      *VDP_DATA = 0;
    }
  }
  goto_xy(0,0);
#else
  goto_xy(0,0);
  clear_eos();
#endif
}

void outbyte(unsigned char ch)
{
  switch (ch)
  {
    case 0:
      break;
    default:
      *VDP_CTRL_L = NAMEA_W + (128 * outbyte_row << 16) + (outbyte_col*2 << 16);
      *VDP_DATA = ch | text_attr;
      outbyte_col++;
      if (outbyte_col >= 40)
      {
        outbyte_col = 39;
      }
      break;
    case '\r':
      outbyte_col = 0;
      break;
    case '\n':
      outbyte_row++;
      if (outbyte_row >= 28)
      {
        // need to handle screen scrolling here
        outbyte_row = 0;
      }
      clear_eol();
      break;
  }
}
#endif

#if 1
#define inbyte() 0
#else
int inbyte(void)
{
  return 0;
}
#endif

int read(int fd, char *buf, int nbytes)
{
  int i = 0;

  for (i = 0; i < nbytes; i++) {
    *(buf + i) = inbyte();
    if ((*(buf + i) == '\n') || (*(buf + i) == '\r')) {
      i++;
      *(buf + i) = '\n';
      outbyte('\r');
      outbyte('\n');
      break;
    } else {
	    outbyte(*(buf+i));
    }
  }
  return i;
}

char *heap_ptr = NULL;
extern char _bss_end;

char *sbrk(int nbytes)
{
    char *base;

    if (!heap_ptr)
        heap_ptr = (char *)&_bss_end;
    base = heap_ptr;
    heap_ptr += nbytes;

    return base;

//    errno = ENOMEM;
//    return (char *) -1;
}


int stat(const char *path, struct stat *buf)
{
    errno = EIO;
    return -1;
}


int unlink(char *path)
{
    errno = EIO;
    return -1;
}


int write(int fd, char *buf, int nbytes)
{
    int i;

    for (i = 0; i < nbytes; i++) {
        if (*(buf + i) == '\n') {
            outbyte ('\r');
        }
        outbyte (*(buf + i));
    }
    return nbytes;
}


/* mrmbase.S
    _exit
    getDebugChar
    inbyte
    putDebugChar
    outbyte
    outln
    outstr
    havebyte
*/


/* crt0.S
    environ
    start
*/


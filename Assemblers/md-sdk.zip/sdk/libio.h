// libio.c stuff
void goto_xy(int x, int y);
void clear_eol(void);
void clear_eos(void);
void clear_screen(void);


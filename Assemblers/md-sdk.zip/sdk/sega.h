// sega.h

#ifndef _SEGA_H_
#define _SEGA_H_


// 68000 interupt-related stuff
#define INTERRUPT_HANDLER void __attribute__((interrupt_handler))
#define INTLEVEL(n) asm volatile("move.w %0<<8+0x2000,%%sr" : : "i" (n))
enum { IL_EXT = 2-1, IL_HSYNC = 4-1, IL_VSYNC = 6-1, IL_NONE = 8-1 };


//-----------------------------------------------------------------------
//  VRAM layout:
//
//  0000 - FFFF pattern generator table     (all of VRAM)
//  C000 - CFFF scroll A name table base    (max size 1000)
//  D800 - DFFF sprite attribute table base (max size 0A00)
//  E000 - EFFF scroll B name table base    (max size 1000)
//  F000 - F7FF window name table base      (max size 0800)
//  FC00 - FFFF H-scroll table base         (max size 0400)
//-----------------------------------------------------------------------

// VDP registers

#define VDP_DATA     ((volatile unsigned short *) 0xC00000)
#define VDP_CTRL     ((volatile unsigned short *) 0xC00004)
#define VDP_STAT     ((volatile unsigned short *) 0xC00004)

#define VDP_DATA_W   VDP_DATA
#define VDP_CTRL_W   VDP_CTRL
#define VDP_DATA_L   ((volatile unsigned long *) 0xC00000)
#define VDP_CTRL_L   ((volatile unsigned long *) 0xC00004)

// controller ports

#define SYS_VERSION  ((volatile unsigned char *) 0xA10001)
#define CTRL1_DATA   ((volatile unsigned char *) 0xA10003)
#define CTRL1_DATA   ((volatile unsigned char *) 0xA10003)
#define CTRL2_DATA   ((volatile unsigned char *) 0xA10005)
#define CTRL3_DATA   ((volatile unsigned char *) 0xA10007)
#define CTRL1_CTRL   ((volatile unsigned char *) 0xA10009)
#define CTRL2_CTRL   ((volatile unsigned char *) 0xA1000B)
#define CTRL3_CTRL   ((volatile unsigned char *) 0xA1000D)
#define CTRL1_TXDATA ((volatile unsigned char *) 0xA1000F)
#define CTRL1_RXDATA ((volatile unsigned char *) 0xA10011)
#define CTRL1_STATUS ((volatile unsigned char *) 0xA10013)
#define CTRL2_TXDATA ((volatile unsigned char *) 0xA10015)
#define CTRL2_RXDATA ((volatile unsigned char *) 0xA10017)
#define CTRL2_STATUS ((volatile unsigned char *) 0xA10019)
#define CTRL3_TXDATA ((volatile unsigned char *) 0xA1001B)
#define CTRL3_RXDATA ((volatile unsigned char *) 0xA1001D)
#define CTRL3_STATUS ((volatile unsigned char *) 0xA1001F)


// standard VDP table addresses

#define PATTERN_TBL     0x0000      // pattern table base (fixed)
#define NAMEA_TBL       0xC000      // name table base for scroll A
#define SPRTATTR_TBL    0xD800      // sprite attribute table base
#define NAMEB_TBL       0xE000      // name table base for scroll B
#define NAMEW_TBL       0xF000      // name table base for window
#define HSCROLL_TBL     0xFC00      // H-scroll table base (V-scroll table is in VSRAM)

// VDP addresses pre-formatted for command register, add (offset<<16)

#define PATTERN_R       0x00000000  // 0000 pattern table base (fixed)
#define NAMEA_R         0x00000003  // C000 name table base for scroll A
#define SPRTATTR_R      0x18000003  // D800 sprite attribute table base
#define NAMEB_R         0x20000003  // E000 name table base for scroll B
#define NAMEW_R         0x30000003  // F000 name table base for window
#define HSCROLL_R       0x3C000003  // FC00 H-scroll table base (V-scroll table is in VSRAM)

#define PATTERN_W       0x40000000  // 0000 pattern table base (fixed)
#define NAMEA_W         0x40000003  // C000 name table base for scroll A
#define SPRTATTR_W      0x58000003  // D800 sprite attribute table base
#define NAMEB_W         0x60000003  // E000 name table base for scroll B
#define NAMEW_W         0x70000003  // F000 name table base for window
#define HSCROLL_W       0x7C000003  // FC00 H-scroll table base (V-scroll table is in VSRAM)
#define CRAM_W          0xC0000000  // color table registers


// PSG address

#define PSG_CONTROL     ((volatile unsigned char *) 0xC00011)


// YM-2612 addresses

#define YM_2612_A0      0xA04000
#define YM_2612_D0      0xA04001
#define YM_2612_A1      0xA04002
#define YM_2612_D1      0xA04003


#endif // _SEGA_H_

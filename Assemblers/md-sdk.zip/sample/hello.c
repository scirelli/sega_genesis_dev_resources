#include "sega.h"
#include "stdio.h"
#include "string.h"
//#include "libio.h"

#include "font.h"

#define HERTZ       60      // vertical sync interrupt rate

#define ARRAY_SIZE(a) (sizeof a / sizeof a[0])

#define NAMEOFS(row,col) ((row)*0x80 + (col)*2)
#define NAMEPOS(row,col) (NAMEOFS(row,col)<<16)


//--------------------------------------------
// global variables
//--------------------------------------------
int frame,hour,minute,second;


//--------------------------------------------
//  Vertical retrace interrupt handler
//--------------------------------------------
volatile int frameCount = 0;     // vsync interrupt frame counter

INTERRUPT_HANDLER VSYNC_INTERRUPT(void)
{
    frameCount++;
}


//--------------------------------------------
//  Initialize Color RAM
//--------------------------------------------
static inline void init_cram(void)
{
    static const short ctab[] =
    {
        // these colors are based on the TMS-9918 color palette

        // color table 0 = normal text
        0x222,0x000,0x2D2,0x6F6,0xF22,0xF64,0x12B,0xFD4,0x22F,0x66F,0x2DD,0x9DD,0x292,0xB4D,0xBBB,0xFFF,
        // color table 1 = inverse video
        0x222,0xFFF,0x2D2,0x6F6,0xF22,0xF64,0x12B,0xFD4,0x22F,0x66F,0x2DD,0x9DD,0x292,0xB4D,0xBBB,0x000,
        // color table 2 = black
        0x222,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,0x000,
        // color table 3 = dim graphics
        0x222,0x000,0x161,0x373,0x711,0x732,0x015,0x762,0x117,0x337,0x166,0x466,0x141,0x526,0x555,0x777
    };

    int i;
    const short *p;

    p = ctab;
    *VDP_CTRL_L = CRAM_W;
    for (i = ARRAY_SIZE(ctab); i; i--)
        *VDP_DATA = *p++;
}

//--------------------------------------------
//  Clear the screen to all BLANK characters
//--------------------------------------------
void ClearScreen(void)
{
    int row,col;

    for (row=0; row<28; row++)
    {
        *VDP_CTRL_L = NAMEA_W + NAMEPOS(row,0);
        for (col=0; col<40; col++)
            *VDP_DATA = 0; //BLANK;
    }
}


//--------------------------------------------
//  Copy a string to the VDP
//--------------------------------------------
void ScrnMsg(const char *s)
{
    while (*s) *VDP_DATA = *s++;
}


//--------------------------------------------
//  Copy a string to the VDP
//--------------------------------------------
void ScrnMsgN(const char *s, int n)
{
    while (n--) *VDP_DATA = *s++;
}


//--------------------------------------------
// Put up main static display
//--------------------------------------------
void do_hello(void)
{
    int row,col;
    int ch;
    char s[64];

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(3, 20-6);
    ScrnMsg("HELLO WORLD!");

    // draw a border around the screen

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(1, 1);
    for (col = 0; col<38; col++)
        *VDP_DATA = 0x7F;

    for (row = 2; row<26; row++)
    {
        *VDP_CTRL_L = NAMEA_W + NAMEPOS(row, 1);
        *VDP_DATA = 0x7F;
        *VDP_CTRL_L = NAMEA_W + NAMEPOS(row, 38);
        *VDP_DATA = 0x7F;
    }

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(26, 1);
    for (col = 0; col<38; col++)
        *VDP_DATA = 0x7F;

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(5, 4);
    // show all character codes
    for (ch=0; ch<128; ch++)
    {
        if ((ch & 0x1F) == 0)
            *VDP_CTRL_L = NAMEA_W + NAMEPOS((ch / 32) + 5, 4);

        *VDP_DATA = ch & 0xFF;
    }

    row = 11;
    col = 4;

    // print information from header

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsgN((char *) 0x0100,16);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsgN((char *) 0x0110,8);

    *VDP_DATA = ' ';
    ScrnMsgN((char *) 0x0118,8);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsgN((char *) 0x0120,34);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsgN((char *) 0x0150,34);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsgN((char *) 0x0180,14);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsg("HW = ");
    ScrnMsgN((char *) 0x0190,16);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsgN((char *) 0x01C8,5);
//    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsgN((char *) 0x01D0,10);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsg("Rgn = ");
    ScrnMsgN((char *) 0x01F0,16);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    sprintf(s,"ROM = %.8lX - %.8lX", *((long *) 0x01A0), *((long*) 0x01A4));
    ScrnMsg(s);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    sprintf(s,"RAM = %.8lX - %.8lX", *((long *) 0x01A8), *((long*) 0x01AC));
    ScrnMsg(s);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    memcpy(s, ((char *) 0x01B0), 4);
    if (s[0] == 'R' && s[1] == 'A')
    {
        sprintf(s,"MEM = %.8lX - %.8lX", *((long *) 0x01B4), *((long*) 0x01B8));
        ScrnMsg(s);
    }
    else ScrnMsg("MEM = none");

#if 0
    row = 15;
    col = 24;

    ch = *((long *) 0x01);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(row++, col);
    ScrnMsg("*");
#endif
}

//--------------------------------------------
// update clock on screen
//--------------------------------------------
void do_clock(void)
{
    char s[64];

    frame++;
    if (frame >= HERTZ)
    {
        frame = 0;
        second++;
        if (second >= 60)
        {
            second = 0;
            minute++;
            if (minute >= 60)
            {
                minute = 0;
                hour++;
            }
        }
    }

    sprintf(s,"%.2d:%.2d:%.2d",hour,minute,second);

    *VDP_CTRL_L = NAMEA_W + NAMEPOS(24,16);
    ScrnMsg(s);
}


//--------------------------------------------
// Initialize system and start outer game loop
//--------------------------------------------
int main(void)
{
    int fc;

    *VDP_CTRL = 0x8104;     // C00004 reg 1 = blank display, disable V-sync, disable DMA
    INTLEVEL(IL_NONE);      // disable 68000 interrupts

    init_cram();
    init_font();
    ClearScreen();

    *VDP_CTRL = 0x8144;     // C00004 reg 1 = unblank display, enable V-sync
    INTLEVEL(IL_VSYNC);     // enable vsync interrupt

    do_hello();             // put up sample display

    // reset clock
    frame  = 0;
    hour   = 0;
    minute = 0;
    second = 0;

    while(1) /* loop forever */
    {
        do_clock();             // update clock

        fc = frameCount;
        while (frameCount == fc) /* wait for next vsync */;
    }

    return 0;
}

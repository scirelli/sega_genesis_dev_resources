#ifndef __FONT_H__
#define __FONT_H__

extern const long font_data[];
void init_font(void);

#define BLANK   0x00

#define UL      0x01
#define UR      0x02
#define LL      0x03
#define LR      0x04
#define TOP     0x05
#define BOT     0x06
#define LFT     0x07
#define RGT     0x08
#define MID     0x09

#define CARET   0x0E
#define HEART   0x0F
#define WAND    0x10
#define F1      0x11
#define F2      0x12
#define F3      0x13
#define F4      0x14

#define EQUIP   0x7F

#endif // __FONT_H__
